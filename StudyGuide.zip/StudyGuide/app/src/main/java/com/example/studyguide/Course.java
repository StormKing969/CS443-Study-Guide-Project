package com.example.studyguide;

public class Course {
    private 
}
