package com.example.studyguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SetActivity extends AppCompatActivity {

    private EditText Title;
    private EditText Question;
    private EditText Answer;
    private Button Save;
    private FirebaseAuth mAuth;
    String InputQuestionNumber;
    String InputQuestion;
    String InputAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set);
        SetUP();

        mAuth = FirebaseAuth.getInstance();

        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collect();
                SendData();
                finish();
            }
        });
    }

    public void Collect() {
        InputQuestionNumber = Title.getText().toString();
        InputQuestion = Question.getText().toString();
        InputAnswer = Answer.getText().toString();
    }

    private void SetUP() {
        Title = findViewById(R.id.NumText);
        Question = findViewById(R.id.QuestionText);
        Answer = findViewById(R.id.AnswerText);
        Save = findViewById(R.id.buttonSave);
    }

    private void SendData() {
        FirebaseDatabase Database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = Database.getReference(InputQuestionNumber);
        UserProfile userProfile = new UserProfile(InputQuestion, InputAnswer);
        myRef.setValue(userProfile);
    }
}
