package com.example.studyguide;

public class Courses {
    public String UserQuestion;
    public String UserAnswer;
    public String UserTitle;

    public Courses() {
    }

    public Courses(String userQuestion, String userAnswer, String userTitle) {
        this.UserQuestion = userQuestion;
        this.UserAnswer = userAnswer;
        this.UserTitle = userTitle;
    }

    public String getUserQuestion() {
        return UserQuestion;
    }

    public void setUserQuestion(String userQuestion) {
        UserQuestion = userQuestion;
    }

    public String getUserAnswer() {
        return UserAnswer;
    }

    public void setUserAnswer(String userAnswer) {
        UserAnswer = userAnswer;
    }

    public String getUserTitle() {
        return UserTitle;
    }

    public void setUserTitle(String userTitle) {
        UserTitle = userTitle;
    }
}
