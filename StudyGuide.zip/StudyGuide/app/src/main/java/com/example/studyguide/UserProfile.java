package com.example.studyguide;

public class UserProfile {
    public String SetQuestion;
    public String SetAnswer;

    public UserProfile(String setQuestion, String setAnswer) {
        this.SetQuestion = setQuestion;
        this.SetAnswer = setAnswer;
    }
}
