package com.example.studyguide;

import android.app.DownloadManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class TestYourselfActivity extends AppCompatActivity {

    ListView lv;
    FirebaseListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_yourself);

        lv = (ListView) findViewById(R.id.listView);
        Query query = FirebaseDatabase.getInstance().getReference().child("User");
        FirebaseListOptions<Courses> options = new FirebaseListOptions.Builder<Courses>()
                .setLayout(R.layout.course)
                .setQuery(query, Courses.class)
                .build();
        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                TextView Title = v.findViewById(R.id.coursetitle);
                TextView Question = v.findViewById(R.id.coursequestion);
                TextView Answer = v.findViewById(R.id.courseanswer);

                Courses title = (Courses) model;
                Title.setText(title.getUserTitle().toString());
                Question.setText(title.getUserTitle().toString());
                Answer.setText(title.getUserTitle().toString());
            }
        };
        lv.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
